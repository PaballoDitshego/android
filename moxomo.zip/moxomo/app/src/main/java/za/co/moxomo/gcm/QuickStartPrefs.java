package za.co.moxomo.gcm;

/**
 * Created by Paballo Ditshego on 8/22/15.
 */
public class QuickStartPrefs {

    public static final String SENT_TOKEN_TO_SERVER = "sentTokenToServer";
    public static final String REGISTRATION_COMPLETE = "registrationComplete";

}