package za.co.moxomo.events;

/**
 * Created by Paballo Ditshego on 8/23/15.
 */
public class NotificationEvent {
    public NotificationEvent() {

    }

}
