package za.co.moxomo;


import androidx.multidex.MultiDexApplication;

public class MoxomoApplication extends MultiDexApplication {
}