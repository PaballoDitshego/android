package za.co.moxomo.events;

/**
 * Created by Paballo Ditshego on 5/25/15.
 */
public class DetailViewEvent {
    private Long id;

    public DetailViewEvent(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }




}
