package za.co.moxomo.model;



public class AlertDTO {
    private String alertId;
    private String[] province;
    private String[] town;
    private String[] tags;
    private String message;
    private String sms;
    private String push;
    private String title;
    private String mobileNumber;
    private String gcmToken;

}
