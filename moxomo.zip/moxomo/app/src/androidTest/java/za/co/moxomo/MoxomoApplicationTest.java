package za.co.moxomo;

import android.app.Application;
import android.test.ApplicationTestCase;


public class MoxomoApplicationTest extends ApplicationTestCase<Application> {
    public MoxomoApplicationTest() {
        super(Application.class);
    }
}